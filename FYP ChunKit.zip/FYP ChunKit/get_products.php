<?php
// get_products.php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

// 1. 连接数据库 (请确保 db_connect.php 文件路径正确)
include 'db_connect.php'; 

// 2. 查询所有产品资料，同时关联分类表获取分类名称 (cake, bread, pastry)
// 并且排除 Cookies 分类
$sql = "SELECT p.*, c.name AS category_name 
        FROM products p 
        JOIN categories c ON p.category_id = c.id
        WHERE c.name != 'Cookies' AND c.name != 'Cookie'";

$result = $conn->query($sql);
$products = [];

if ($result && $result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        // 处理 Subcategory：去掉数据库里存储的双引号
        $sub = trim($row['subcategory'], '"');

        // 整理数据结构以完全匹配原本 menu.js 的格式
        $products[] = [
            "id" => (int)$row['id'],
            "name" => $row['name'],
            "price" => (float)$row['price'],
            "category" => strtolower($row['category_name']), // 转为 'cake', 'bread' 等
            "subcategory" => $sub,
            "image" => $row['image'],
            "description" => $row['description'],
            "fullDescription" => $row['full_description'],
            "ingredients" => $row['ingredients'],
            "weight" => $row['weight'],
            "allergens" => $row['allergens'],
            "rating" => (float)$row['rating'],
            "reviewCount" => (int)$row['review_count'],
            // 将数据库里逗号分隔的标签字符串转回 JS 数组
            "tags" => !empty($row['tags']) ? explode(',', $row['tags']) : [],
            "size" => $row['size_info']
        ];
    }
}

// 3. 以 JSON 格式输出给前端
echo json_encode($products);
$conn->close();
?>