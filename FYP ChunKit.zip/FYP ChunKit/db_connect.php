<?php
// 数据库配置信息
$servername = "localhost"; // 通常是 localhost
$username = "root";        // 你的数据库用户名（XAMPP 默认是 root）
$password = "";            // 你的数据库密码（XAMPP 默认是空）
$dbname = "bakery_house";  // 👈 重点：这里必须填入你在 phpMyAdmin 里创建的数据库名字

// 创建连接
$conn = new mysqli($servername, $username, $password, $dbname);

// 检查连接是否成功
if ($conn->connect_error) {
    die("数据库连接失败: " . $conn->connect_error);
}

// 设置编码，防止中文乱码
$conn->set_charset("utf8mb4");
?>