<footer>
    <div class="container">
        <div class="footer-content">
            <div class="footer-logo">
                <img src="Bakery House Logo.png" alt="BakeryHouse">
            </div>
            
            <p>Sweet & Delicious</p>
            
            <div class="footer-links">
                <a href="mainpage.php">Home</a>
                <a href="menu.php">Menu</a>
                <a href="about_us.php">About</a>
                <a href="contact_us.php">Contact</a>
                <a href="privacypolicy.php">Privacy Policy</a>
                <a href="termservice.php">Terms of Service</a>
            </div>
            
            <p>&copy; <?php echo date("Y"); ?> BakeryHouse. All rights reserved.</p>
        </div>
    </div>
</footer>